# Guess-The-Number

Hello GitHub world! 🌈✌

This is thee game "Guess-The-Number", original name, isn't it?

## What the heck is this? ❓

Well, this is a game where you have two players: one will put a series of 5 numbers and the other will try to guess.
Both will play once (unless you say "sim" when the program asks if you want to play again), and wil have 10 tries to guess the other's sequence.

Good luck warriors!

## Credits 📜

* This was made in our "Técnicas de Programação" class, so the idea isn't totally original
* The project was leaded by Vasco Martins (vasco@se3me.com) with the help of Miguel Ferreira (miguel@se3me.com) (however, this is a team's job, always teamup with the ones you like the most)

## Send us suggestions 📥

We'd love if you, there, in the other side of the computer send us some suggestions, or even some code of yours based on ours!
You can send to:

* vasco@se3me.com
* miguel@se3me.com

See ya, and remember to spend time with those who are different

# 'Cause it's good to be different


www.se3me.com || www.solutions.se3me.com
